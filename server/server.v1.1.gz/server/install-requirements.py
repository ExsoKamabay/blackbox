from os import name, system
from time import sleep
# install requirements


def install(*package):
    for name in package:
        if name == 'nt':
            system(f'pip install {name}')
        else:
            try:
                system(f'sudo pip3 install {name}')
            except:
                system(f'pip3 install {name}')
    print("OK SELESAI!")


if __name__ == '__main__':
    print('Install Packages Requirements!')
    sleep(3)
    install(
        'requests', 'art', 'stringcolor'
    )
